import 'package:flutter/material.dart';
import 'package:hive/hive.dart';
import 'package:ricknmorti/api/api_service.dart';
import '../models/character.dart';

class CharacterProvider with ChangeNotifier {
  final RickAndMortyApi _api = RickAndMortyApi();
  List<Character> _characters = [];
  List<Character> get characters => _characters;
  late Box<Character> _favoritesBox;

  CharacterProvider() {
    _favoritesBox = Hive.box('favorites');
    fetchCharacters();
  }

  Future<void> fetchCharacters({int page = 1}) async {
    try {
      final characterData = await _api.fetchCharacters(page: page);
      _characters = characterData.map((json) => Character.fromJson(json)).toList();
      notifyListeners();
    } catch (e) {
      
    }
  }

  void toggleFavorite(Character character) {
    if (_favoritesBox.containsKey(character.id)) {
      _favoritesBox.delete(character.id);
    } else {
      _favoritesBox.put(character.id, character);
    }
    notifyListeners();
  }

  List<Character> get favorites => _favoritesBox.values.toList();
}
