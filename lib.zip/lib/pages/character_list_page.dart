import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:ricknmorti/widget/character_card.dart';
import '../providers/character_provider.dart';
import '../providers/theme_provider.dart';

import '../models/character.dart';

class CharacterListPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final provider = Provider.of<CharacterProvider>(context);
    final themeProvider = Provider.of<ThemeProvider>(context);

    return Scaffold(
      appBar: AppBar(
        title: Text('Characters'),
        actions: [
          IconButton(
            icon: Icon(
              themeProvider.themeMode == ThemeMode.light
                  ? Icons.dark_mode
                  : Icons.light_mode,
            ),
            onPressed: () {
              themeProvider.toggleTheme();
            },
          ),
        ],
      ),
      body: ListView.builder(
        itemCount: provider.characters.length,
        itemBuilder: (context, index) {
          final character = provider.characters[index];
          final isFavorite = provider.favorites.contains(character);

          return CharacterCard(
            character: character,
            isFavorite: isFavorite,
            onFavoriteToggle: () => provider.toggleFavorite(character),
            onTap: () => _showCharacterDetails(context, character),
          );
        },
      ),
    );
  }

  void _showCharacterDetails(BuildContext context, Character character) {
    showModalBottomSheet(
      context: context,
      builder: (context) => Container(
        padding: EdgeInsets.all(16.0),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Image.network(character.image),
            SizedBox(height: 8),
            Text(
              character.name,
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            Text('Status: ${character.status}'),
            Text('Species: ${character.species}'),
          ],
        ),
      ),
    );
  }
}
